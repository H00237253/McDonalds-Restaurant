const express = require('express');
const cors = require('cors');
const mongoClient = require('mongodb').MongoClient;
const bodyParser = require('body-parser'); //read form data and form fields
const methodOverride = require('method-override'); //to support PUT and DELETE FROM browsers

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(methodOverride('_method'));

//const mongoServerURL = "mongodb://localhost:27017";
const mongoServerURL = "mongodb://user1:abc123@ds127624.mlab.com:27624/restaurantdb";

//default route / - display all food
app.get('/' ,(request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to food
		const restaurantdb = db.db("restaurantdb");

		//read from restaurantdb food collection
		restaurantdb.collection("food").find({}).toArray((err, foodArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(foodArray));
		});

		//close the connection to the db
		db.close();
	});
});

//get one food by name - used in update and delete web pages
app.get('/food/:foodName', (request, response, next) => {

	const FoodName = request.params.foodName;

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to food
		const restaurantdb = db.db("restaurantdb");

		console.log(foodName);
		//build the query filter
		let query = {food_name:foodName};

		//read from restaurantdb food collection
		restaurantdb.collection("food").find(query).toArray((err, foodArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(foodArray));
		});

		//close the connection to the db
		db.close();
	});

});

//hardcoded route 
app.get('/main', (request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to foood
		const restaurantdb = db.db("restaurantdb");

		//read from restaurantdb food collection
		restaurantdb.collection("food").find({food_type:"main"}).toArray((err, foodArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(foodArray));
		});

		//close the connection to the db
		db.close();
	});
});

//example to used to handle many routes using request parameter
//here the request parameter is :food_type
app.get('/:food_type', (request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to food
		const restaurantdb = db.db("restaurantdb");
		let food_typeValue = request.params.food_type;
		if (food_typeValue == "main")
			food_typeValue = "Main";
		else if (food_typeValue == "sides")
			food_typeValue = "Sides";
		else if (food_typeValue == "beverages")
			food_typeValue = "Beverages";
		console.log(food_typeValue);
		//build the query filter
		let query = {food_type:food_typeValue};

		//read from restaurantdb food collection
		restaurantdb.collection("food").find(query).toArray((err, foodArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(foodArray));
		});

		//close the connection to the db
		db.close();
	});
});

//add a new food - using HTTP POST method
app.post('/food', (request, response, next) => {
	//access the form fields by the same names as in the HTML form
	const foodId = request.body.foodId;
	console.log(foodId);
	const foodName = request.body.foodName;
	const foodType = request.body.food_type;
	const foodDescription = request.body.description;
	let foodPrice = request.body.price;
	//convert price to number
	foodPrice = parseFloat(foodPrice);

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to restaurantdb
		const restaurantdb = db.db("restaurantdb");
		
		const newFood = {food_id:foodId, food_name:foodName, food_type:foodType, description:foodDescription,
						price:foodPrice};
		//insert to restaurantdb food collection
		restaurantdb.collection("food").insertOne(newFood, (err, result) => {
			if (err) {
				console.log(err.message);
			}

			if (result.insertedCount == 1) {
				
				response.redirect("/static/index.html");
			}
			else
				response.end("Food: " + foodName + " could not be added!!");

		});

		//close the connection to the db
		db.close();
	});	
});

//update food - uisng HTTP PUT method
app.put('/food', (request, response, next) => {
	console.log("in PUT");
	const foodName = request.param('foodName');
	const foodType = request.param('food_type');
	const foodDescription = request.param('description');
	let foodPrice = request.param('price');
	//convert price to number
	foodPrice = parseFloat(foodPrice);

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to food
		const restaurantdb = db.db("restaurantdb");
		
		//we are updating by the food_name
		const updateFilter = {food_name:foodName};
		const updateValues = {$set:{food_type:foodType, description:foodDescription,
						price:foodPrice}};
		//insert from restaurantdb food collection
		restaurantdb.collection("food").updateOne(updateFilter, updateValues, (err, res) => {
			if (err) {
				console.log(err.message);
			}
			
			response.redirect("/static/index.html");
		});

		//close the connection to the db
		db.close();
	});	
});

//delete food by food name
app.delete('/food', (request, response, next) => {
	const foodName = request.param('foodName');

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to food
		const restaurantdb = db.db("restaurantdb");
		
		//we are deleting by the food_name
		const deleteFilter = {food_name:foodName};

		//insert from restaurantdb food collection
		restaurantdb.collection("food").deleteOne(deleteFilter, (err, res) => {
			if (err) {
				console.log(err.message);
			}

			//const responseJSON = {deleteCount:res.result.n}; //n - how many docs deleted
			//response.send(JSON.stringify(responseJSON));

			if (res.deletedCount > 0) {
				response.redirect("/static/index.html");
			}
			else {
				response.send("<script>alert(\"deleted \" +foodName);</script>");
			}
		});

		//close the connection to the db
		db.close();
	});	
});


//set the route for static HTML files to /static
//actual folder containing HTML files will be public
app.use('/static', express.static('public'));

//start the web server
const port = process.env.PORT;
app.listen(port, ()=> {
	console.log("server listening on " + port);
});

